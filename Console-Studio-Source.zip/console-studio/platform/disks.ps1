$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
function Records {
 $page=@(Get-CimInstance Win32_PageFileUsage -ErrorAction SilentlyContinue | ForEach-Object { $_.Name.Substring(0,2) })
 foreach($d in @(Get-Disk)) {
  $vols=@(); $protected=($d.IsBoot -or $d.IsSystem -or $d.IsOffline -or $d.IsReadOnly -or $d.IsClustered)
  foreach($p in @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue)) {
   if($p.IsBoot -or $p.IsSystem){$protected=$true}
   $v=$p | Get-Volume -ErrorAction SilentlyContinue
   if($p.DriveLetter){$mount=[string]$p.DriveLetter+':\'; if($page -contains ([string]$p.DriveLetter+':')){$protected=$true}
    if($v){$vols+=@{mount=$mount;fs=[string]$v.FileSystem;size=[double]$v.Size;free=[double]$v.SizeRemaining;uuid=[string]$v.UniqueId;label=[string]$v.FileSystemLabel;partition=[int]$p.PartitionNumber}}
   }
  }
  [PSCustomObject]@{id=[string]$d.Number;name=[string]$d.FriendlyName;serial=([string]$d.SerialNumber).Trim();unique=[string]$d.UniqueId;path=[string]$d.Path;size=[double]$d.Size;bus=[string]$d.BusType;protected=[bool]$protected;volumes=@($vols)}
 }
}
ConvertTo-Json -InputObject @(Records) -Depth 6 -Compress
