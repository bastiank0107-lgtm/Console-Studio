const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('studio',Object.freeze({
 reload:()=>ipcRenderer.invoke('reload'),language:lang=>ipcRenderer.invoke('language',lang),catalog:()=>ipcRenderer.invoke('catalog'),news:id=>ipcRenderer.invoke('news',id),open:url=>ipcRenderer.invoke('open',url),pick:(id,key)=>ipcRenderer.invoke('pick',{id,key}),devices:()=>ipcRenderer.invoke('devices'),prepare:options=>ipcRenderer.invoke('prepare',options),write:options=>ipcRenderer.invoke('write',options),export:id=>ipcRenderer.invoke('export',id),saveInfo:id=>ipcRenderer.invoke('save-info',id),progress:fn=>{const handler=(_,e)=>fn(e);ipcRenderer.on('progress',handler);return()=>ipcRenderer.removeListener('progress',handler);}
}));
