(()=>{
 const overlay=document.getElementById('startup');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 let shown=false;try{shown=sessionStorage.getItem('studio-intro')==='shown';sessionStorage.setItem('studio-intro','shown');}catch{}
 if(shown||reduced){overlay.remove();return;}
 const start=performance.now(),surfaces=[...document.querySelectorAll('body > aside, body > main')];
 surfaces.forEach(el=>el.inert=true);
 let finished=false,minTimer,maxTimer;
 const finish=(immediate=false)=>{if(finished)return;finished=true;clearTimeout(minTimer);clearTimeout(maxTimer);surfaces.forEach(el=>el.inert=false);window.removeEventListener('studio-ready',ready);window.removeEventListener('studio-startup-error',failed);window.removeEventListener('keydown',key);if(immediate){overlay.remove();return;}overlay.classList.add('startup-out');setTimeout(()=>overlay.remove(),440);};
 const ready=()=>{minTimer=setTimeout(()=>finish(),Math.max(0,1500-(performance.now()-start)));};
 const failed=()=>finish(true);
 const key=e=>{if(e.key==='Escape')finish(true);};
 window.addEventListener('studio-ready',ready,{once:true});
 window.addEventListener('studio-startup-error',failed,{once:true});
 window.addEventListener('keydown',key);
 maxTimer=setTimeout(()=>finish(),3500);
})();
