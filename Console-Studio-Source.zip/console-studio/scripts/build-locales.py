from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
d=json.loads((root/'data/translations.en.json').read_text())
pattern=re.compile('|'.join(re.escape(k) for k in sorted(d,key=len,reverse=True)))
def tr(s):return pattern.sub(lambda m:d[m.group()],s)
s=(root/'ui/app.js').read_text();original=next(l for l in s.splitlines() if l.startswith('const modelLabel='));translated=tr(s);translated=translated.replace(next(l for l in translated.splitlines() if l.startswith('const modelLabel=')),original);translated=translated.replace("toLocaleString('de-DE'","toLocaleString('en-GB'").replace('Console-Studio-Guide.html','Console-Studio-Anleitung.html')
(root/'ui/app.en.js').write_text(translated)
html=(root/'ui/index.html').read_text();(root/'ui/static.en.json').write_text(json.dumps(d,ensure_ascii=False))
# Shared, local-only boot: translate static UI before loading the selected renderer.
(root/'ui/strings.js').write_text('window.STUDIO_STRINGS='+json.dumps(d,ensure_ascii=False)+';')
