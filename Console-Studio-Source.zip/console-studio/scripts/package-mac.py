"""Package an already signed macOS app without changing or excluding bundle files."""
import os, stat, zipfile, plistlib, hashlib, argparse
from pathlib import Path

def add(z,p,name):
    if p.is_symlink():
        i=zipfile.ZipInfo(name);i.create_system=3;i.external_attr=(stat.S_IFLNK|0o777)<<16
        z.writestr(i,os.readlink(p))
    elif p.is_dir():
        for c in sorted(p.iterdir()):add(z,c,name+'/'+c.name)
    else:z.write(p,name)

def verify(filename):
    count=0
    with zipfile.ZipFile(filename) as z:
        assert z.testzip() is None
        names=z.namelist();assert len(names)==len(set(names)), 'Duplicate entries'
        for n in names:
            if not n.endswith('/_CodeSignature/CodeResources'):continue
            base=n.removesuffix('_CodeSignature/CodeResources')
            manifest=plistlib.loads(z.read(n))
            for rel,entry in manifest.get('files2',{}).items():
                if not isinstance(entry,dict):continue
                target=base+rel
                if 'hash2' in entry:
                    assert target in names, 'Missing signed resource: '+target
                    assert hashlib.sha256(z.read(target)).digest()==entry['hash2'], 'Changed signed resource: '+target
                    count+=1
                if 'symlink' in entry:
                    assert z.read(target).decode()==entry['symlink'], 'Changed symlink: '+target
                    assert stat.S_ISLNK(z.getinfo(target).external_attr>>16)
    print('Verified',count,'sealed resource hashes:',filename,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('app');p.add_argument('output');p.add_argument('--docs',required=True);a=p.parse_args()
    output=Path(a.output);prefix=output.stem
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
        add(z,Path(a.app),prefix+'/Console Studio.app')
        for doc in ['README.md','TESTS.txt','MAC-START.txt']:
            z.write(Path(a.docs)/doc,prefix+'/'+doc)
    verify(output)
