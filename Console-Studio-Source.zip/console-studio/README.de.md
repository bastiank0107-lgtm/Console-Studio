# Console Studio 1.1.1 — Preview

Ein unabhängiger Desktop-Begleiter für Homebrew auf 27 Konsolenfamilien von Xbox,
PlayStation und Nintendo. Oberfläche in Schwarz, Grau und Weiß mit Goldakzenten.

## Start

- Windows: ZIP vollständig entpacken, dann `ConsoleStudio.exe` öffnen. Die EXE
  zusammen mit allen mitgelieferten Dateien im Ordner belassen.
- Mac: Das zur CPU passende ZIP entpacken und `Console Studio.app` nach Programme
  ziehen. Apple Silicon = Mac mit Apple-Chip; Intel = Intel-Mac. macOS 13 oder neuer.
- Kein Node.js, Python oder .NET für die fertigen Apps erforderlich.
- Internet ist für Paketdownloads und aktuelle Projektmeldungen erforderlich.
- Die Apps sind nicht mit einem kommerziellen Entwicklerzertifikat signiert
  bzw. nicht bei Apple notarisiert. Mac-Pakete sind nur ad-hoc signiert.
  Betriebssysteme können beim Öffnen nachfragen.
  Keine globale Schutzfunktion abschalten.

## Was die App macht

- Katalog mit Modell-/Firmwaregrenzen, Risiken, Originalquellen und weiteren Schritten.
- GitHub-Release- und Commit-Meldungen bzw. GitLab-Commit-Meldungen von ns2jb.
  Abruf- und Veröffentlichungsdatum werden getrennt angezeigt. Offline wird ein
  vorhandener Cache ausdrücklich als veraltet gekennzeichnet.
- 12 Konsolenprofile können USB-/SD-/Memory-Stick-Dateien vorbereiten.
- Automatische Downloads aus festgelegten Originalquellen; Releases werden beim
  Vorbereiten neu abgefragt. Erforderliche lokale Dateien werden über einen
  Dateidialog gewählt. Keine unangekündigten Hintergrundinstallationen.
- Paketprüfung vor jedem Löschen, explizite Geräteauswahl und Bestätigung.
- Optionale FAT32/MBR-Formatierung externer Geräte bis 32 GiB, mit Systemdialog
  für Administratorrechte. Größere vorhandene FAT32-Volumes können ohne
  Formatierung verwendet werden. PSP-Speicher wird nicht formatiert.
- Vorhandene Zieldateien werden nicht überschrieben. Benutze ein leeres Medium
  oder sichere und entferne gleichnamige Dateien zuvor selbst.
- Vollständiges Zurücklesen und SHA-256-Vergleich nach dem Schreiben.
- HTML-Anleitung auf jedem erstellten Medium und Export eines geprüften
  Paketordners zum manuellen Übertragen.

## Welche Vorbereitung konkret enthalten ist

| Konsole | Automatische Vorbereitung | Was anschließend zusätzlich nötig ist |
|---|---|---|
| Xbox 360 | RBB + aktueller PeerPressure-Installer auf USB | Unterstütztes Mainboard, HDD, Backup und Installation auf der Konsole |
| PS2 | FreeMcBoot-Installer auf USB | Passender ELF-Einstieg und kompatible Memory Card/PS2 |
| PS3 | Lokal gewähltes PUP nach PS3/UPDATE | Unabhängige SHA-256, exaktes Modell und geeigneter HEN-/CFW-Weg |
| PS4 | GoldHEN-Payload auf USB, Profil 11.10 | PPPwn-Host, passende stage2, Ethernet-Einstieg |
| PSP | ARK-Live-Einstieg auf vorhandenem Speicher | Firmware 6.61 und Start des Loaders auf der PSP |
| GameCube | Swiss als ipl.dol | Bereits eingerichtetes PicoBoot und passender SD-Adapter |
| Wii / Wii mini | HackMii boot.elf auf USB | BlueBomb-Bluetooth-Einstieg gemäß Guide |
| Wii U | Aktuelle Aroma- und Basis-Payloads automatisch auf SD | Browser-Einstieg, NAND-Backup und weitere Einrichtung |
| Switch | Atmosphère/Hekate-Dateien auf microSD | Ungepatchte V1, RCM, Payload-Sender, Backup/emuMMC-Konfiguration |
| 3DS / 2DS | Luma-Basisdateien auf SD | Modellspezifischer Erstinstallations-Exploit und Finalisierung |
| DSi | TWiLight-Menu++-Basisdateien auf SD | Passender Memory-Pit-Einstieg und zusätzliche Schritte |

Die zwei Wii-Modelle zählen als eigene Profile. Basisdateien und Payloads sind
kein vollständiger Einsteck-und-fertig-Jailbreak. Die App zeigt diese Grenzen
vor der Erstellung. Original-Xbox-FATX, Memory-Card-Rohimages, Ethernet-Exploits,
Browser-Exploits, Payload-Injektion und Lötarbeiten werden nicht automatisch
ausgeführt. Zu diesen Wegen gibt es Anleitungen und Quellen.

Die aktuelle Switch-2-Primärquelle ist https://gitlab.com/pepsipu/ns2jb.
Sie beschreibt eine FS-Forschungsdemo für konkrete Voraussetzungen, keine
persistente Custom Firmware. Die App verwechselt sie nicht mit einem
universellen USB-Installer.

## Aktualität und Vertrauen

Katalog und Kompatibilitätsregeln: 27.10.2026. Neue Release-Meldungen ändern
Kompatibilitätsregeln nicht automatisch. Schau vor dem Einsatz in die verlinkte
Primärquelle. Veränderte Archivstrukturen führen zu einem Abbruch statt zu
erratenen Zielpfaden. Einige Projekte veröffentlichen keine separate SHA-256;
in diesem Fall wird das in der Paketübersicht klar angezeigt. Der lokal
berechnete Hash dient der Kopierprüfung und ersetzt keine Herausgeber-Signatur.

Beim GitHub-Abruf gilt das öffentliche API-Limit. Fehlermeldungen und veraltete
Cache-Daten werden nicht als aktuelle Bestätigung dargestellt. Keine API-Tokens
oder Konten erforderlich. Bei reinen Info-Plattformen ohne Projektfeed stehen
die Originalquellen statt erfundener Live-Nachrichten bereit.

Downloads und vorbereitete Pakete werden lokal im Benutzer-Anwendungsordner
unter Console Studio/work gespeichert. Sie enthalten unter Umständen mehrere
GB Daten. Arbeitsordner können bei geschlossener App gelöscht werden. Die App
verwendet keine Telemetrie und lädt keine Konsolen-Seriennummern oder lokalen
Dateien zu einem Dienst hoch.

## Teststand

Die Oberfläche wurde als echte Electron-App unter Linux gestartet und bedient.
Firmware-Abweisung, Navigation, Suche, Archivpfade, Geräteidentität und die
Dateikopie wurden geprüft. Mehrere Profile wurden mit den tatsächlichen
Originalarchiven vollständig vorbereitet und validiert. Details stehen im
beiliegenden TESTS.txt.

Die Windows-/Mac-Pakete wurden unter Linux zusammengestellt. Ein echter
Windows-/Mac-Start, UAC-/Administrator-Dialog, die physische FAT32-Formatierung
und Installationen auf den Konsolen konnten hier nicht getestet werden.
Die Ausgabe ist deshalb eine Preview und keine hardwarezertifizierte Lösung.

## Entwicklung

Node.js 24, `npm ci`, `npm test`, `npm start`.
`node build.mjs` erstellt Windows x64, macOS arm64 und macOS x64 mit Electron 45.
Die fertigen Apps enthalten nur Laufzeit-Abhängigkeiten. Quellcode und
Abhängigkeits-Lockdatei sind im separaten Source-ZIP enthalten.

Alle Konsolennamen sind Eigentum ihrer jeweiligen Rechteinhaber.
Drittprojekte behalten ihre eigenen Lizenzen. Die App verkauft keine Exploits
und enthält keine kommerziellen Spielabbilder. Benötigte Inhalte werden aus
den im Projektleitfaden angegebenen Quellen geladen bzw. vom Nutzer gewählt.
