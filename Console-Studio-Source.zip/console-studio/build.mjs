import {packager} from '@electron/packager';
import path from 'node:path';
const root=path.dirname(new URL(import.meta.url).pathname);
for (const [platform,arch] of [['win32','x64'],['darwin','arm64'],['darwin','x64']]) {
 console.log('BUILD',platform,arch);
 const outputs=await packager({dir:root,out:path.resolve(root,'../builds'),name:'Console Studio',executableName:platform==='win32'?'ConsoleStudio':'Console Studio',platform,arch,electronVersion:'45.0.0',overwrite:true,prune:true,asar:false,icon:path.join(root,platform==='darwin'?'ui/icon.icns':'ui/icon.ico'),appBundleId:'local.consolestudio.desktop',appCategoryType:'public.app-category.utilities',ignore:[/^\/tests($|\/)/,/^\/build\.mjs$/,/^\/\.git($|\/)/],osxSign:false,osxNotarize:false});
 console.log('DONE',outputs.join(','));
}
